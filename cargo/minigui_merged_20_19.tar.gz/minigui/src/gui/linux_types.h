#ifndef _LINUX_TYPES_H
#define _LINUX_TYPES_H

//modify by zkswe
#ifndef unchar
#define unchar unsigned char
#endif
#ifndef ushort
//#define ushort unsigned short
typedef unsigned short ushort;
#endif
#ifndef uint
#define uint unsigned int
#endif
#ifndef ulong
#define ulong unsigned long
#endif

#ifndef u_char
#define u_char unsigned char
#endif
#ifndef u_short
#define u_short unsigned short
#endif
#ifndef u_int
#define u_int unsigned int
#endif
#ifndef u_long
#define u_long unsigned long
#endif

#endif /* _LINUX_TYPES_H */
