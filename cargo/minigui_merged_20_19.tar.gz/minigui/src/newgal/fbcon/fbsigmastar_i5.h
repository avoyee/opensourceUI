#ifndef __FB_SIGMASTAR_I5_H__
#define __FB_SIGMASTAR_I5_H__

#include <mi_common.h>
#include <mi_sys.h>
#include <mi_sys_datatype.h>

#define Sigmastar_HWAccelBlit NULL
#define Sigmastar_HWAccelFillRect NULL
#define Sigmastar_HWAccelColorKey Sigmastar_I5_HWAccelColorKey
#define Sigmastar_HWAccelAlpha Sigmastar_I5_HWAccelAlpha

#endif
